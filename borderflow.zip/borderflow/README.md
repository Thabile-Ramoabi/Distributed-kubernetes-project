# BorderFlow — CS4430 Distributed Database Systems
## Week 6 Final Submission

**Course:** CS4430 – Distributed Database Systems  
**Project:** BorderFlow — Distributed Offline-First Container Tracking System  
**Deployment:** Kubernetes on Docker Desktop  

---

## System Overview

BorderFlow is a distributed, offline-first container logistics tracking system
spanning four logical sites:

| Site | Name                       | Location            | Role                        |
|------|----------------------------|---------------------|-----------------------------|
| 1    | Maseru Depot               | Maseru, Lesotho     | Origin / primary sync anchor |
| 2    | Caledonspoort Border Post  | Ficksburg, SA       | Offline-first leaf node      |
| 3    | Johannesburg Hub           | Johannesburg, SA    | Secondary sync anchor        |
| 4    | Port of Durban             | Durban, SA          | Leaf / final delivery node   |

Each site runs an independent PostgreSQL instance with its own data fragment.
Sites communicate asynchronously via **NATS JetStream** (the sync bus).

---

## Architecture

```
localhost:30080
       │
   [Gateway]        ← scatter-gather, control tower UI
   /     |  \  \
  [S1] [S2] [S3] [S4]    ← FastAPI + sync worker per site
   |     |    |    |
  [PG1][PG2][PG3][PG4]   ← PostgreSQL (one per site)
        \____\___|____\
               [NATS]    ← JetStream event bus (offline-first sync)
```

**Offline-first design:**  
Each site writes locally first, publishes to NATS second. If NATS is unreachable,
writes still succeed locally. The sync worker reconnects and replays buffered events
with a durable JetStream consumer (no events lost).

**Idempotency:** Every event carries a UUID. All inserts use `ON CONFLICT DO NOTHING`.

**Conflict resolution:** Last-Write-Wins by timestamp (appropriate for append-only audit trail).

---

## Prerequisites

- Docker Desktop with Kubernetes enabled  
  (Settings → Kubernetes → Enable Kubernetes → Apply & Restart)
- `kubectl` connected to docker-desktop context
- Docker CLI

Verify:
```bash
kubectl config current-context   # should print: docker-desktop
kubectl get nodes                 # should show one node: Ready
```

---

## Step 1 — Build Docker Images

```bash
# From the project root directory:

# Build site application image (used by all 4 site deployments)
docker build -t borderflow/site-app:latest src/site_app/

# Build gateway image
docker build -t borderflow/gateway:latest src/gateway/

# Verify images exist
docker images | grep borderflow
```

---

## Step 2 — Deploy to Kubernetes

```bash
# Apply everything in one command (kustomize)
kubectl apply -k .

# Watch pods come up (takes ~60 seconds for postgres to initialize)
kubectl get pods -n borderflow -w
```

Wait until all pods show `Running` and `READY 1/1`:

```
NAME                              READY   STATUS    RESTARTS
gateway-xxx                       1/1     Running   0
nats-xxx                          1/1     Running   0
postgres-border-xxx               1/1     Running   0
postgres-depot-xxx                1/1     Running   0
postgres-hub-xxx                  1/1     Running   0
postgres-port-xxx                 1/1     Running   0
site-border-xxx                   1/1     Running   0
site-depot-xxx                    1/1     Running   0
site-hub-xxx                      1/1     Running   0
site-port-xxx                     1/1     Running   0
```

---

## Step 3 — Seed the Databases

```bash
chmod +x seed/seed.sh
./seed/seed.sh
```

This copies `seed/init.sql` to each postgres pod and runs it.
The schema and reference data (sites, clients, vehicles, drivers)
are seeded on all four databases. Sample containers are loaded on Site 1.

---

## Step 4 — Access the System

| Endpoint                        | Description                          |
|---------------------------------|--------------------------------------|
| http://localhost:30080/         | Control Tower UI (web browser)       |
| http://localhost:30080/sites/health | Live status of all four sites    |
| http://localhost:30080/control-tower/containers | All containers     |
| http://localhost:30080/docs     | Gateway API docs (Swagger)           |

Each site also exposes auto-generated API docs:
```bash
# Port-forward individual site for direct access (optional)
kubectl port-forward svc/site-depot -n borderflow 8001:8000
# Then open: http://localhost:8001/docs
```

---

## Step 5 — Run the Failure & Recovery Demo

```bash
chmod +x demo/failure_recovery_demo.sh
./demo/failure_recovery_demo.sh
```

**What the demo shows:**
1. All four sites are online and healthy.
2. A `DEPARTED` milestone is recorded at the Depot.
3. The Border Post (Site 2) is **taken offline** (`kubectl scale --replicas=0`).
4. More milestones are recorded at Depot and Hub **while Border is offline**.
5. Border Post is **restored** (`kubectl scale --replicas=1`).
6. The sync worker reconnects to NATS and **replays all missed events**.
7. The Control Tower shows the **complete timeline** — no events lost.

---

## API Quick Reference

### Record a Milestone
```bash
curl -X POST http://localhost:30080/site/depot/milestones \
  -H "Content-Type: application/json" \
  -d '{"container_id":"MSCU1234567","event_type":"departed","notes":"Left 09:00"}'
```

### Initiate a Handover
```bash
curl -X POST http://localhost:30080/site/depot/handovers \
  -H "Content-Type: application/json" \
  -d '{
    "container_id":"MSCU1234567",
    "from_site_id":1,
    "to_site_id":2,
    "operator_id":"clerk-001",
    "condition_notes":"Seal intact"
  }'
```

### Get Container Timeline (all sites)
```bash
curl http://localhost:30080/control-tower/milestones/MSCU1234567
```

### Report an Incident
```bash
curl -X POST http://localhost:30080/site/border/incidents \
  -H "Content-Type: application/json" \
  -d '{
    "container_id":"MSCU1234567",
    "trip_id":"<trip-uuid>",
    "type":"document",
    "description":"Missing customs form"
  }'
```

---

## Teardown

```bash
# Delete all BorderFlow resources
kubectl delete namespace borderflow

# Remove Docker images
docker rmi borderflow/site-app:latest borderflow/gateway:latest
```

---

## Project File Structure

```
borderflow/
├── kustomization.yaml           # single deploy entry point
├── k8s/
│   ├── config/
│   │   ├── namespace.yaml
│   │   └── configmap.yaml
│   ├── storage/
│   │   └── pvcs.yaml
│   └── deployments/
│       ├── nats.yaml
│       ├── postgres-all-sites.yaml
│       ├── sites.yaml
│       └── gateway.yaml
├── src/
│   ├── site_app/
│   │   ├── main.py              # FastAPI site service
│   │   ├── sync.py              # NATS sync worker
│   │   ├── start.sh             # launches both processes
│   │   ├── requirements.txt
│   │   └── Dockerfile
│   └── gateway/
│       ├── main.py              # API gateway + control tower UI
│       ├── requirements.txt
│       └── Dockerfile
├── seed/
│   ├── init.sql                 # schema + seed data
│   └── seed.sh                  # seeds all 4 postgres pods
└── demo/
    └── failure_recovery_demo.sh # Week 6 demo script
```

---

## Design Decisions

| Decision | Rationale |
|----------|-----------|
| One PostgreSQL pod per site | Mirrors real-world physical autonomy |
| NATS JetStream (not Kafka) | Lightweight, fits Docker Desktop easily, built-in persistence |
| Durable consumers | Sync resumes exactly where it left off after reconnect |
| UUID primary keys everywhere | Global uniqueness without coordination |
| `ON CONFLICT DO NOTHING` | Safe idempotent replay of any event |
| Single Docker image for all sites | DRY; configured entirely via env vars |
| `kubectl scale --replicas=0` for failure | Simple, reproducible, no extra tools |
| NodePort on 30080 | Works out-of-the-box on Docker Desktop without ingress controller |
