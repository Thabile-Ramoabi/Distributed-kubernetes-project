-- ============================================================
--  BorderFlow — Database Schema & Seed Data
--  Run on ALL four site databases.
--  Tables are shared; each site only populates its own fragment.
-- ============================================================

-- ── Replicated tables (seeded identically on all sites) ──────────────────────

CREATE TABLE IF NOT EXISTS site (
    site_id   SERIAL PRIMARY KEY,
    name      TEXT NOT NULL,
    location  TEXT NOT NULL,
    type      TEXT NOT NULL   -- depot | border | hub | port
);

CREATE TABLE IF NOT EXISTS client (
    client_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        TEXT NOT NULL,
    contact     TEXT
);

CREATE TABLE IF NOT EXISTS vehicle (
    vehicle_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    registration_no TEXT UNIQUE NOT NULL,
    type            TEXT NOT NULL    -- truck | flatbed | reefer
);

CREATE TABLE IF NOT EXISTS driver (
    driver_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name      TEXT NOT NULL,
    licence   TEXT,
    phone     TEXT
);

-- ── Fragmented tables (each site stores only its own rows) ────────────────────

CREATE TABLE IF NOT EXISTS container (
    container_id    TEXT PRIMARY KEY,   -- ISO shipping code, e.g. MSCU1234567
    status          TEXT NOT NULL DEFAULT 'at_depot',
    current_site_id INT  REFERENCES site(site_id),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS consignment (
    consignment_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    container_id        TEXT REFERENCES container(container_id),
    client_id           UUID REFERENCES client(client_id),
    origin_site_id      INT  REFERENCES site(site_id),
    destination_site_id INT  REFERENCES site(site_id),
    declared_goods      TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trip (
    trip_id             UUID PRIMARY KEY,
    origin_site_id      INT  REFERENCES site(site_id),
    destination_site_id INT  REFERENCES site(site_id),
    departure_time      TIMESTAMPTZ,
    arrival_time        TIMESTAMPTZ,
    status              TEXT NOT NULL DEFAULT 'active'  -- active | completed | cancelled
);

CREATE TABLE IF NOT EXISTS assignment (
    assignment_id UUID PRIMARY KEY,
    trip_id       UUID REFERENCES trip(trip_id),
    container_id  TEXT REFERENCES container(container_id),
    driver_id     UUID REFERENCES driver(driver_id),
    vehicle_id    UUID REFERENCES vehicle(vehicle_id),
    assigned_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS milestone (
    event_id     UUID PRIMARY KEY,
    container_id TEXT REFERENCES container(container_id),
    site_id      INT  REFERENCES site(site_id),
    event_type   TEXT NOT NULL,    -- departed|arrived|queued|cleared|gate_in|released|delivered
    timestamp    TIMESTAMPTZ NOT NULL,
    notes        TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS handover (
    handover_id     UUID PRIMARY KEY,
    container_id    TEXT REFERENCES container(container_id),
    from_site_id    INT  REFERENCES site(site_id),
    to_site_id      INT  REFERENCES site(site_id),
    operator_id     TEXT,
    condition_notes TEXT DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'pending',  -- pending | confirmed
    initiated_at    TIMESTAMPTZ,
    confirmed_at    TIMESTAMPTZ,
    confirmed_by    TEXT
);

CREATE TABLE IF NOT EXISTS incident (
    incident_id  UUID PRIMARY KEY,
    container_id TEXT REFERENCES container(container_id),
    trip_id      TEXT,
    site_id      INT  REFERENCES site(site_id),
    type         TEXT NOT NULL,    -- breakdown | document | damage | security
    description  TEXT,
    reported_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Outbox for pending sync (written offline, flushed on reconnect)
CREATE TABLE IF NOT EXISTS outbox (
    id         BIGSERIAL PRIMARY KEY,
    subject    TEXT NOT NULL,
    payload    JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    synced     BOOLEAN DEFAULT FALSE
);

-- ── Seed: Replicated reference data (same on all sites) ──────────────────────

INSERT INTO site (site_id, name, location, type) VALUES
    (1, 'Maseru Depot',             'Maseru, Lesotho',             'depot'),
    (2, 'Caledonspoort Border Post', 'Ficksburg Border, SA',       'border'),
    (3, 'Johannesburg Hub',          'Johannesburg, South Africa',  'hub'),
    (4, 'Port of Durban',            'Durban, South Africa',        'port')
ON CONFLICT (site_id) DO NOTHING;

INSERT INTO client (client_id, name, contact) VALUES
    ('11111111-0000-0000-0000-000000000001', 'Lesotho Textiles Ltd',   '+266 5000 1111'),
    ('11111111-0000-0000-0000-000000000002', 'Mountain Kingdom Goods',  '+266 5000 2222')
ON CONFLICT (client_id) DO NOTHING;

INSERT INTO vehicle (vehicle_id, registration_no, type) VALUES
    ('22222222-0000-0000-0000-000000000001', 'LS 001 GP', 'truck'),
    ('22222222-0000-0000-0000-000000000002', 'LS 002 KZN', 'flatbed')
ON CONFLICT (vehicle_id) DO NOTHING;

INSERT INTO driver (driver_id, name, licence, phone) VALUES
    ('33333333-0000-0000-0000-000000000001', 'Thabo Mokoena',  'DR-001', '+266 6001 0001'),
    ('33333333-0000-0000-0000-000000000002', 'Mpho Letsie',    'DR-002', '+266 6001 0002')
ON CONFLICT (driver_id) DO NOTHING;

-- ── Seed: Fragmented data (depot fragment — only loaded on Site 1 DB) ─────────
-- (The init script checks $SITE_ID and only runs the matching block)

-- Container starts at depot (site 1)
INSERT INTO container (container_id, status, current_site_id) VALUES
    ('MSCU1234567', 'at_depot', 1),
    ('MSCU7654321', 'at_depot', 1)
ON CONFLICT (container_id) DO NOTHING;

INSERT INTO consignment (consignment_id, container_id, client_id,
                          origin_site_id, destination_site_id, declared_goods) VALUES
    ('44444444-0000-0000-0000-000000000001',
     'MSCU1234567', '11111111-0000-0000-0000-000000000001', 1, 4, 'Woven textiles'),
    ('44444444-0000-0000-0000-000000000002',
     'MSCU7654321', '11111111-0000-0000-0000-000000000002', 1, 4, 'Agricultural equipment')
ON CONFLICT (consignment_id) DO NOTHING;
