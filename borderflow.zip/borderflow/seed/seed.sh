#!/bin/bash
# ============================================================
#  BorderFlow — Seed all four site databases
#  Run this after `kubectl apply -k k8s/` and waiting for
#  all postgres pods to reach Running state.
# ============================================================

set -e

NS="borderflow"
SQL="seed/init.sql"

echo "==> Waiting for all postgres pods to be ready..."
kubectl wait --for=condition=ready pod -l app=postgres-depot  -n $NS --timeout=120s
kubectl wait --for=condition=ready pod -l app=postgres-border -n $NS --timeout=120s
kubectl wait --for=condition=ready pod -l app=postgres-hub    -n $NS --timeout=120s
kubectl wait --for=condition=ready pod -l app=postgres-port   -n $NS --timeout=120s

echo "==> Seeding Site 1 (Depot)..."
DEPOT_POD=$(kubectl get pod -l app=postgres-depot -n $NS -o jsonpath='{.items[0].metadata.name}')
kubectl cp $SQL $NS/$DEPOT_POD:/tmp/init.sql
kubectl exec -n $NS $DEPOT_POD -- psql -U bf_user -d borderflow -f /tmp/init.sql

echo "==> Seeding Site 2 (Border)..."
BORDER_POD=$(kubectl get pod -l app=postgres-border -n $NS -o jsonpath='{.items[0].metadata.name}')
kubectl cp $SQL $NS/$BORDER_POD:/tmp/init.sql
kubectl exec -n $NS $BORDER_POD -- psql -U bf_user -d borderflow -f /tmp/init.sql

echo "==> Seeding Site 3 (Hub)..."
HUB_POD=$(kubectl get pod -l app=postgres-hub -n $NS -o jsonpath='{.items[0].metadata.name}')
kubectl cp $SQL $NS/$HUB_POD:/tmp/init.sql
kubectl exec -n $NS $HUB_POD -- psql -U bf_user -d borderflow -f /tmp/init.sql

echo "==> Seeding Site 4 (Port)..."
PORT_POD=$(kubectl get pod -l app=postgres-port -n $NS -o jsonpath='{.items[0].metadata.name}')
kubectl cp $SQL $NS/$PORT_POD:/tmp/init.sql
kubectl exec -n $NS $PORT_POD -- psql -U bf_user -d borderflow -f /tmp/init.sql

echo ""
echo "✅  All sites seeded. Control Tower: http://localhost:30080"
