-- ============================================================
--  BorderFlow — Seed Data
--  Matched exactly to the actual schema columns
--  Run on ALL four site databases
-- ============================================================

-- ── Sites (replicated on all 4 databases) ────────────────────
INSERT INTO site (site_id, site_name, role) VALUES
  ('site-s1', 'Maseru Depot',              'depot'),
  ('site-s2', 'Caledonspoort Border Post', 'border'),
  ('site-s3', 'Johannesburg Hub',           'hub'),
  ('site-s4', 'Port of Durban',             'port')
ON CONFLICT (site_id) DO NOTHING;

-- ── Clients (replicated on all 4 databases) ───────────────────
INSERT INTO client (client_id, name, email) VALUES
  ('aaaaaaaa-0000-0000-0000-000000000001', 'Lesotho Textiles Ltd',  'info@lstextiles.co.ls'),
  ('aaaaaaaa-0000-0000-0000-000000000002', 'Mountain Kingdom Goods', 'ops@mkg.co.ls')
ON CONFLICT (client_id) DO NOTHING;

-- ── Vehicles (owned by Depot — site-s1) ───────────────────────
INSERT INTO vehicle (vehicle_id, plate, type, owner_site_id) VALUES
  ('bbbbbbbb-0000-0000-0000-000000000001', 'LSGP',  'truck',   'site-s1'),
  ('bbbbbbbb-0000-0000-0000-000000000002', 'LS 002 KZN', 'flatbed', 'site-s1')
ON CONFLICT (vehicle_id) DO NOTHING;

-- ── Drivers (owned by Depot — site-s1) ────────────────────────
INSERT INTO driver (driver_id, full_name, license_no, owner_site_id) VALUES
  ('cccccccc-0000-0000-0000-000000000001', 'Thabo Mokoena', 'DR001', 'site-s1'),
  ('cccccccc-0000-0000-0000-000000000002', 'Mpho Letsie',   'DR002', 'site-s1')
ON CONFLICT (driver_id) DO NOTHING;

INSERT INTO driver (driver_id, full_name, license_no, owner_site_id) VALUES ('Driver-01', 'Thabo Mokoena', 'DR003', 'site-s1') ON CONFLICT (driver_id) DO NOTHING;

-- ── Containers (currently at Depot — site-s1) ─────────────────
INSERT INTO container (container_id, serial_no, status, current_site_id, owner_site_id, lamport_ts) VALUES
  ('dddddddd-0000-0000-0000-000000000001', 'MSCU1234567', 'at_depot', 'site-s1', 'site-s1', 0),
  ('dddddddd-0000-0000-0000-000000000002', 'MSCU7654321', 'at_depot', 'site-s1', 'site-s1', 0)
ON CONFLICT (container_id) DO NOTHING;

-- ── Consignments ──────────────────────────────────────────────
INSERT INTO consignment (consignment_id, client_id, origin_site_id, description) VALUES
  ('eeeeeeee-0000-0000-0000-000000000001',
   'aaaaaaaa-0000-0000-0000-000000000001', 'site-s1', 'Woven textiles — Maseru to Durban'),
  ('eeeeeeee-0000-0000-0000-000000000002',
   'aaaaaaaa-0000-0000-0000-000000000002', 'site-s1', 'Agricultural equipment — Maseru to Durban')
ON CONFLICT (consignment_id) DO NOTHING;

-- ── Consignment ↔ Container links ─────────────────────────────
INSERT INTO consignment_container (consignment_id, container_id) VALUES
  ('eeeeeeee-0000-0000-0000-000000000001', 'dddddddd-0000-0000-0000-000000000001'),
  ('eeeeeeee-0000-0000-0000-000000000002', 'dddddddd-0000-0000-0000-000000000002')
ON CONFLICT DO NOTHING;
