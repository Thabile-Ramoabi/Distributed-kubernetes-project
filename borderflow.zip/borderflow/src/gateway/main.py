# ============================================================
#  BorderFlow — API Gateway
#  Single entry point on localhost:30080.
#  Routes writes to the correct site; aggregates reads for the
#  control-tower (scatter-gather across all 4 sites).
# ============================================================

import os, asyncio
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
import httpx

SITE_URLS = {
    "depot":  os.environ.get("DEPOT_URL",  "http://site-depot:8000"),
    "border": os.environ.get("BORDER_URL", "http://site-border:8000"),
    "hub":    os.environ.get("HUB_URL",    "http://site-hub:8000"),
    "port":   os.environ.get("PORT_URL",   "http://site-port:8000"),
}

SITE_ID_MAP = {"1": "depot", "2": "border", "3": "hub", "4": "port"}

app = FastAPI(title="BorderFlow Gateway")

# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"gateway": "ok"}

@app.get("/sites/health")
async def sites_health():
    """Ping all four sites; shows which are reachable (online/offline demo)."""
    results = {}
    async with httpx.AsyncClient(timeout=3.0) as client:
        for name, url in SITE_URLS.items():
            try:
                r = await client.get(f"{url}/health")
                results[name] = r.json()
            except Exception:
                results[name] = {"status": "OFFLINE"}
    return results

# ── Control Tower — scatter-gather across all sites ───────────────────────────

@app.get("/control-tower/containers")
async def all_containers():
    """Aggregate container list from every site."""
    all_rows = []
    async with httpx.AsyncClient(timeout=5.0) as client:
        tasks = [client.get(f"{url}/containers") for url in SITE_URLS.values()]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        for name, resp in zip(SITE_URLS.keys(), responses):
            if isinstance(resp, Exception):
                all_rows.append({"site": name, "error": "OFFLINE"})
            else:
                for row in resp.json():
                    row["_site"] = name
                    all_rows.append(row)
    return all_rows

@app.get("/control-tower/milestones/{container_id}")
async def container_timeline(container_id: str):
    """Gather full milestone history for a container across all sites."""
    all_milestones = []
    async with httpx.AsyncClient(timeout=5.0) as client:
        tasks = [
            client.get(f"{url}/milestones/{container_id}")
            for url in SITE_URLS.values()
        ]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        for name, resp in zip(SITE_URLS.keys(), responses):
            if not isinstance(resp, Exception) and resp.status_code == 200:
                for m in resp.json():
                    m["_site"] = name
                    all_milestones.append(m)
    # Sort chronologically
    all_milestones.sort(key=lambda x: x.get("timestamp", ""))
    return all_milestones

# ── Proxy writes to the correct site ─────────────────────────────────────────

@app.post("/site/{site_name}/{resource}")
async def proxy_write(site_name: str, resource: str, body: dict):
    if site_name not in SITE_URLS:
        raise HTTPException(400, f"Unknown site: {site_name}")
    url = f"{SITE_URLS[site_name]}/{resource}"
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            r = await client.post(url, json=body)
            return r.json()
        except httpx.ConnectError:
            raise HTTPException(503, f"Site {site_name} is currently offline")

# ── Minimal Control Tower UI ──────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def ui():
    return """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BorderFlow — Control Tower</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 2rem; background: #f4f6f8; }
    h1   { color: #1a3c5e; }
    .card { background: #fff; border-radius: 8px; padding: 1rem;
            margin: 1rem 0; box-shadow: 0 2px 6px rgba(0,0,0,.1); }
    .site { display: inline-block; padding: .3rem .8rem; border-radius: 4px;
            margin: .3rem; font-weight: bold; }
    .ok      { background: #d4edda; color: #155724; }
    .offline { background: #f8d7da; color: #721c24; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #dee2e6; padding: .5rem; text-align: left; }
    th { background: #1a3c5e; color: #fff; }
    button { background: #1a3c5e; color: #fff; border: none; padding: .5rem 1rem;
             border-radius: 4px; cursor: pointer; margin: .3rem; }
    input  { padding: .4rem; border: 1px solid #ccc; border-radius: 4px; margin: .3rem; }
  </style>
</head>
<body>
  <h1>&#x1F4E6; BorderFlow — Control Tower</h1>

  <div class="card">
    <h2>Site Status</h2>
    <div id="sites">Loading…</div>
    <button onclick="loadSites()">Refresh</button>
  </div>

  <div class="card">
    <h2>All Containers (across all sites)</h2>
    <button onclick="loadContainers()">Load</button>
    <div id="containers"></div>
  </div>

  <div class="card">
    <h2>Container Timeline</h2>
    <input id="cid" placeholder="Container ID" style="width:300px">
    <button onclick="loadTimeline()">Get Timeline</button>
    <div id="timeline"></div>
  </div>

  <script>
    async function loadSites() {
      const r = await fetch('/sites/health');
      const d = await r.json();
      document.getElementById('sites').innerHTML = Object.entries(d).map(
        ([name, info]) =>
          `<span class="site ${info.status === 'OFFLINE' ? 'offline' : 'ok'}">
             ${name}: ${info.status === 'OFFLINE' ? 'OFFLINE' : 'ONLINE'}
           </span>`
      ).join('');
    }

    async function loadContainers() {
      const r = await fetch('/control-tower/containers');
      const rows = await r.json();
      if (!rows.length) { document.getElementById('containers').innerHTML = '<p>No containers found.</p>'; return; }
      const cols = Object.keys(rows[0]);
      document.getElementById('containers').innerHTML =
        `<table><tr>${cols.map(c=>`<th>${c}</th>`).join('')}</tr>` +
        rows.map(row => `<tr>${cols.map(c=>`<td>${row[c]??''}</td>`).join('')}</tr>`).join('') +
        '</table>';
    }

    async function loadTimeline() {
      const cid = document.getElementById('cid').value.trim();
      if (!cid) return;
      const r = await fetch('/control-tower/milestones/' + encodeURIComponent(cid));
      const rows = await r.json();
      if (!rows.length) { document.getElementById('timeline').innerHTML = '<p>No milestones found.</p>'; return; }
      const cols = Object.keys(rows[0]);
      document.getElementById('timeline').innerHTML =
        `<table><tr>${cols.map(c=>`<th>${c}</th>`).join('')}</tr>` +
        rows.map(row => `<tr>${cols.map(c=>`<td>${row[c]??''}</td>`).join('')}</tr>`).join('') +
        '</table>';
    }

    loadSites();
  </script>
</body>
</html>
"""
