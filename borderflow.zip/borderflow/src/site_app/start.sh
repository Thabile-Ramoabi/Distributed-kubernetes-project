#!/bin/sh
# Start sync worker in background, then start the API server in foreground.
# If the API server exits, the container exits (Kubernetes will restart it).
python sync.py &
exec uvicorn main:app --host 0.0.0.0 --port 8000
