# ============================================================
#  BorderFlow — Site Application
#  Shared service used by all 4 sites (depot, border, hub, port)
#  Configured entirely through environment variables.
#
#  Each site:
#    • Has its own PostgreSQL fragment (local writes)
#    • Publishes events to NATS on every write
#    • Sync worker (sync.py) subscribes and applies remote events
# ============================================================

import os, uuid, asyncio
from datetime import datetime
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import asyncpg
import nats

# ── Configuration (from environment / ConfigMap) ──────────────────────────────
SITE_ID   = int(os.environ["SITE_ID"])
SITE_NAME = os.environ["SITE_NAME"]
DB_HOST   = os.environ["DB_HOST"]
DB_USER   = os.environ.get("DB_USER", "bf_user")
DB_PASS   = os.environ.get("DB_PASSWORD", "bf_pass")
DB_NAME   = os.environ.get("DB_NAME", "borderflow")
NATS_URL  = os.environ.get("NATS_URL", "nats://nats-service:4222")

# ── Global state ──────────────────────────────────────────────────────────────
db_pool   = None
nc        = None          # NATS connection (None when offline)
js        = None          # JetStream context

# ── Lifespan (startup / shutdown) ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool, nc, js
    # DB pool
    db_pool = await asyncpg.create_pool(
        host=DB_HOST, port=5432, user=DB_USER,
        password=DB_PASS, database=DB_NAME, min_size=2, max_size=10
    )
    # NATS — optional; site stays up if broker unreachable (offline-first)
    try:
        nc = await nats.connect(NATS_URL, connect_timeout=3)
        js = nc.jetstream()
        # Ensure stream exists (idempotent)
        try:
            await js.add_stream(name="EVENTS", subjects=["events.>"])
        except Exception:
            pass   # already exists
        print(f"[{SITE_NAME}] Connected to NATS")
    except Exception as e:
        print(f"[{SITE_NAME}] NATS unavailable (offline mode): {e}")
        nc, js = None, None
    yield
    # Shutdown
    await db_pool.close()
    if nc:
        await nc.drain()

app = FastAPI(title=f"BorderFlow — Site {SITE_NAME}", lifespan=lifespan)

# ── Helpers ───────────────────────────────────────────────────────────────────

def new_uuid() -> str:
    return str(uuid.uuid4())

async def publish(subject: str, payload: dict):
    """Publish event to NATS JetStream; silently skip if offline."""
    if js is None:
        return
    import json
    try:
        await js.publish(subject, json.dumps(payload).encode())
    except Exception as e:
        print(f"[{SITE_NAME}] Publish failed (will retry on reconnect): {e}")

# ── Models ────────────────────────────────────────────────────────────────────

class HandoverIn(BaseModel):
    container_id:   str
    from_site_id:   int
    to_site_id:     int
    operator_id:    str
    condition_notes: str = ""

class MilestoneIn(BaseModel):
    container_id: str
    event_type:   str           # departed | arrived | queued | cleared | gate_in | released | delivered
    notes:        str = ""

class IncidentIn(BaseModel):
    container_id: str
    trip_id:      str
    type:         str           # breakdown | document | damage | security
    description:  str

class TripIn(BaseModel):
    origin_site_id:      int
    destination_site_id: int
    driver_id:           str
    vehicle_id:          str
    container_id:        str

# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"site": SITE_NAME, "site_id": SITE_ID, "status": "ok",
            "nats": nc is not None}

# ── Containers (local fragment only) ─────────────────────────────────────────

@app.get("/containers")
async def list_containers():
    """Return all containers whose current_site_id matches this site."""
    rows = await db_pool.fetch(
        "SELECT * FROM container WHERE current_site_id = $1", SITE_ID
    )
    return [dict(r) for r in rows]

@app.get("/containers/{container_id}")
async def get_container(container_id: str):
    row = await db_pool.fetchrow(
        "SELECT * FROM container WHERE container_id = $1", container_id
    )
    if not row:
        raise HTTPException(404, "Container not found at this site")
    return dict(row)

# ── Milestones ────────────────────────────────────────────────────────────────

@app.post("/milestones")
async def record_milestone(m: MilestoneIn):
    """
    Record a cross-border milestone event.
    Writes locally then publishes to NATS for global visibility.
    The event_id (UUID) ensures idempotency on replay.
    """
    event_id  = new_uuid()
    ts        = datetime.utcnow()
    await db_pool.execute(
        """INSERT INTO milestone (event_id, container_id, site_id, event_type, timestamp, notes)
           VALUES ($1,$2,$3,$4,$5,$6)
           ON CONFLICT (event_id) DO NOTHING""",
        event_id, m.container_id, SITE_ID, m.event_type, ts, m.notes
    )
    await publish(f"events.milestone.{SITE_ID}", {
        "event_id": event_id, "container_id": m.container_id,
        "site_id": SITE_ID, "event_type": m.event_type,
        "timestamp": ts.isoformat(), "notes": m.notes,
        "origin_site": SITE_NAME
    })
    return {"event_id": event_id, "status": "recorded"}

@app.get("/milestones/{container_id}")
async def get_milestones(container_id: str):
    rows = await db_pool.fetch(
        "SELECT * FROM milestone WHERE container_id = $1 ORDER BY timestamp ASC",
        container_id
    )
    return [dict(r) for r in rows]

# ── Handovers ─────────────────────────────────────────────────────────────────

@app.post("/handovers")
async def initiate_handover(h: HandoverIn):
    """
    Step 1 of two-step handover: originating site records 'pending'.
    Step 2: receiving site calls PATCH /handovers/{id}/confirm.
    Correctness: both sides must write; we use NATS for the notification.
    Under failure: pending handovers are visible and retried on reconnect.
    """
    handover_id = new_uuid()
    ts          = datetime.utcnow()
    await db_pool.execute(
        """INSERT INTO handover
               (handover_id, container_id, from_site_id, to_site_id,
                operator_id, condition_notes, status, initiated_at)
           VALUES ($1,$2,$3,$4,$5,$6,'pending',$7)
           ON CONFLICT (handover_id) DO NOTHING""",
        handover_id, h.container_id, h.from_site_id, h.to_site_id,
        h.operator_id, h.condition_notes, ts
    )
    await publish(f"events.handover.initiated", {
        "handover_id": handover_id, "container_id": h.container_id,
        "from_site_id": h.from_site_id, "to_site_id": h.to_site_id,
        "operator_id": h.operator_id, "timestamp": ts.isoformat()
    })
    return {"handover_id": handover_id, "status": "pending"}

@app.patch("/handovers/{handover_id}/confirm")
async def confirm_handover(handover_id: str, operator_id: str):
    """Step 2: receiving site confirms the handover."""
    ts = datetime.utcnow()
    result = await db_pool.execute(
        """UPDATE handover SET status='confirmed', confirmed_at=$1, confirmed_by=$2
           WHERE handover_id=$3 AND status='pending'""",
        ts, operator_id, handover_id
    )
    if result == "UPDATE 0":
        raise HTTPException(404, "Handover not found or already confirmed")
    await publish("events.handover.confirmed", {
        "handover_id": handover_id, "confirmed_by": operator_id,
        "timestamp": ts.isoformat()
    })
    return {"handover_id": handover_id, "status": "confirmed"}

# ── Trips ─────────────────────────────────────────────────────────────────────

@app.post("/trips")
async def create_trip(t: TripIn):
    """
    Create a trip and assignment.
    Duplicate-prevention: checks for existing active assignment of same
    container before inserting (within this site's fragment).
    """
    async with db_pool.acquire() as conn:
        async with conn.transaction():
            # Check for duplicate active assignment
            existing = await conn.fetchval(
                """SELECT COUNT(*) FROM assignment a
                   JOIN trip tr ON a.trip_id = tr.trip_id
                   WHERE a.container_id = $1 AND tr.status = 'active'""",
                t.container_id
            )
            if existing > 0:
                raise HTTPException(409, "Container already assigned to an active trip")

            trip_id = new_uuid()
            ts      = datetime.utcnow()
            await conn.execute(
                """INSERT INTO trip (trip_id, origin_site_id, destination_site_id,
                                    departure_time, status)
                   VALUES ($1,$2,$3,$4,'active')""",
                trip_id, t.origin_site_id, t.destination_site_id, ts
            )
            assign_id = new_uuid()
            await conn.execute(
                """INSERT INTO assignment (assignment_id, trip_id, container_id,
                                          driver_id, vehicle_id, assigned_at)
                   VALUES ($1,$2,$3,$4,$5,$6)""",
                assign_id, trip_id, t.container_id, t.driver_id, t.vehicle_id, ts
            )
    await publish(f"events.trip.created.{SITE_ID}", {
        "trip_id": trip_id, "container_id": t.container_id,
        "origin_site_id": t.origin_site_id, "driver_id": t.driver_id,
        "timestamp": ts.isoformat()
    })
    return {"trip_id": trip_id, "assignment_id": assign_id}

# ── Incidents ─────────────────────────────────────────────────────────────────

@app.post("/incidents")
async def report_incident(i: IncidentIn):
    inc_id = new_uuid()
    ts     = datetime.utcnow()
    await db_pool.execute(
        """INSERT INTO incident (incident_id, container_id, trip_id, type, description, reported_at, site_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7)
           ON CONFLICT (incident_id) DO NOTHING""",
        inc_id, i.container_id, i.trip_id, i.type, i.description, ts, SITE_ID
    )
    await publish(f"events.incident.{SITE_ID}", {
        "incident_id": inc_id, "container_id": i.container_id,
        "trip_id": i.trip_id, "type": i.type, "timestamp": ts.isoformat(),
        "site_id": SITE_ID
    })
    return {"incident_id": inc_id}

# ── Local event inbox (sync worker writes here) ───────────────────────────────

@app.get("/events/inbox")
async def get_inbox():
    """Show buffered outbound events (pending sync)."""
    rows = await db_pool.fetch(
        "SELECT * FROM outbox WHERE synced = FALSE ORDER BY created_at ASC LIMIT 100"
    )
    return [dict(r) for r in rows]
