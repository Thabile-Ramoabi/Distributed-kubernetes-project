# ============================================================
#  BorderFlow — Sync Worker
#  Runs as a background task inside each site container.
#  Subscribes to NATS JetStream and applies events from OTHER
#  sites into the local database (offline-first reconciliation).
#
#  Idempotency: every event carries a UUID (event_id / handover_id /
#  trip_id). All INSERT statements use ON CONFLICT DO NOTHING,
#  so replaying a message is safe.
#
#  Conflict resolution strategy: Last-Write-Wins by timestamp.
#  (Simple and appropriate for an audit-trail / append-only model.)
# ============================================================

import os, asyncio, json
from datetime import datetime

import asyncpg
import nats

SITE_ID   = int(os.environ["SITE_ID"])
SITE_NAME = os.environ["SITE_NAME"]
DB_HOST   = os.environ["DB_HOST"]
DB_USER   = os.environ.get("DB_USER",     "bf_user")
DB_PASS   = os.environ.get("DB_PASSWORD", "bf_pass")
DB_NAME   = os.environ.get("DB_NAME",     "borderflow")
NATS_URL  = os.environ.get("NATS_URL",    "nats://nats-service:4222")

RETRY_INTERVAL = 10   # seconds between reconnect attempts

# ─────────────────────────────────────────────────────────────────────────────

async def handle_milestone(conn, data: dict):
    """Apply a milestone event received from another site."""
    await conn.execute(
        """INSERT INTO milestone
               (event_id, container_id, site_id, event_type, timestamp, notes)
           VALUES ($1,$2,$3,$4,$5,$6)
           ON CONFLICT (event_id) DO NOTHING""",
        data["event_id"], data["container_id"], data["site_id"],
        data["event_type"],
        datetime.fromisoformat(data["timestamp"]),
        data.get("notes", "")
    )

async def handle_handover_initiated(conn, data: dict):
    """Record an incoming handover that was initiated at another site."""
    await conn.execute(
        """INSERT INTO handover
               (handover_id, container_id, from_site_id, to_site_id,
                operator_id, condition_notes, status, initiated_at)
           VALUES ($1,$2,$3,$4,$5,$6,'pending',$7)
           ON CONFLICT (handover_id) DO NOTHING""",
        data["handover_id"], data["container_id"],
        data["from_site_id"], data["to_site_id"],
        data.get("operator_id", ""), data.get("condition_notes", ""),
        datetime.fromisoformat(data["timestamp"])
    )

async def handle_handover_confirmed(conn, data: dict):
    await conn.execute(
        """UPDATE handover
           SET status='confirmed', confirmed_at=$1, confirmed_by=$2
           WHERE handover_id=$3 AND status='pending'""",
        datetime.fromisoformat(data["timestamp"]),
        data.get("confirmed_by", ""), data["handover_id"]
    )

async def handle_trip(conn, data: dict):
    """Replicate trip creation from another site (read-only reference)."""
    await conn.execute(
        """INSERT INTO trip
               (trip_id, origin_site_id, destination_site_id,
                departure_time, status)
           VALUES ($1,$2,$3,$4,'active')
           ON CONFLICT (trip_id) DO NOTHING""",
        data["trip_id"],
        data["origin_site_id"],
        data.get("destination_site_id", 0),
        datetime.fromisoformat(data["timestamp"])
    )

async def handle_incident(conn, data: dict):
    await conn.execute(
        """INSERT INTO incident
               (incident_id, container_id, trip_id, type, description, reported_at, site_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7)
           ON CONFLICT (incident_id) DO NOTHING""",
        data["incident_id"], data["container_id"], data.get("trip_id",""),
        data["type"], data.get("description",""),
        datetime.fromisoformat(data["timestamp"]), data["site_id"]
    )

HANDLERS = {
    "milestone":          handle_milestone,
    "handover.initiated": handle_handover_initiated,
    "handover.confirmed": handle_handover_confirmed,
    "trip":               handle_trip,
    "incident":           handle_incident,
}

# ─────────────────────────────────────────────────────────────────────────────

async def run_sync_worker():
    pool = await asyncpg.create_pool(
        host=DB_HOST, port=5432, user=DB_USER,
        password=DB_PASS, database=DB_NAME, min_size=1, max_size=3
    )
    print(f"[sync-{SITE_NAME}] DB pool ready")

    while True:
        try:
            nc = await nats.connect(NATS_URL, connect_timeout=5)
            js = nc.jetstream()
            print(f"[sync-{SITE_NAME}] Connected to NATS")

            # Durable consumer — resumes from last ack'd message after reconnect
            consumer_name = f"sync-{SITE_NAME}"
            sub = await js.subscribe(
                "events.>",
                durable=consumer_name,
                manual_ack=True
            )

            async for msg in sub.messages:
                try:
                    subject = msg.subject          # e.g. "events.milestone.2"
                    data    = json.loads(msg.data)

                    # Skip events we ourselves published
                    if data.get("site_id") == SITE_ID or \
                       data.get("origin_site") == SITE_NAME:
                        await msg.ack()
                        continue

                    # Route to correct handler
                    for key, handler in HANDLERS.items():
                        if key in subject:
                            async with pool.acquire() as conn:
                                await handler(conn, data)
                            break

                    await msg.ack()
                    print(f"[sync-{SITE_NAME}] Applied: {subject}")

                except Exception as e:
                    print(f"[sync-{SITE_NAME}] Error processing msg: {e}")
                    await msg.nak()   # re-deliver after backoff

        except Exception as e:
            print(f"[sync-{SITE_NAME}] NATS disconnected ({e}). "
                  f"Retrying in {RETRY_INTERVAL}s …")
            await asyncio.sleep(RETRY_INTERVAL)

if __name__ == "__main__":
    asyncio.run(run_sync_worker())
