#!/bin/bash
# ============================================================
#  BorderFlow — Failure & Recovery Demo Script
#  CS4430 Week 6 Demonstration
#
#  Scenario:
#    1. Border Post (Site 2) goes offline mid-workflow.
#    2. Depot continues recording milestones locally.
#    3. Border comes back online.
#    4. Events sync automatically via NATS JetStream.
#    5. Control Tower shows complete timeline — no data lost.
# ============================================================

NS="borderflow"
GW="http://localhost:30080"

echo ""
echo "============================================================"
echo "  BorderFlow — Failure & Recovery Demo"
echo "============================================================"
echo ""

# Step 1: Show all sites are healthy
echo "[Step 1] All sites online — checking health..."
curl -s $GW/sites/health | python3 -m json.tool
echo ""
read -p "Press ENTER to continue..."

# Step 2: Record a departure milestone at Depot (Site 1)
echo "[Step 2] Recording DEPARTED milestone at Depot (Site 1)..."
curl -s -X POST http://localhost:30080/site/depot/milestones \
  -H "Content-Type: application/json" \
  -d '{"container_id":"MSCU1234567","event_type":"departed","notes":"Left depot 09:00"}' \
  | python3 -m json.tool
echo ""
read -p "Press ENTER to simulate Border Post going OFFLINE..."

# Step 3: Take the Border Post offline
echo "[Step 3] Simulating Border Post (Site 2) FAILURE..."
kubectl scale deployment site-border -n $NS --replicas=0
kubectl scale deployment postgres-border -n $NS --replicas=0
echo "  => Border Post is now OFFLINE"
sleep 3

# Step 4: Show sites status — border should show OFFLINE
echo "[Step 4] Checking site health — border should be OFFLINE..."
curl -s $GW/sites/health | python3 -m json.tool
echo ""
read -p "Press ENTER to record milestones while Border is offline..."

# Step 5: Record milestones at other sites while border is offline
echo "[Step 5] Recording ARRIVED milestone at Depot while Border is offline..."
curl -s -X POST $GW/site/depot/milestones \
  -H "Content-Type: application/json" \
  -d '{"container_id":"MSCU1234567","event_type":"arrived_border","notes":"Arrived border gate"}' \
  | python3 -m json.tool

echo "[Step 5b] Recording milestone at Hub (Site 3) independently..."
curl -s -X POST $GW/site/hub/milestones \
  -H "Content-Type: application/json" \
  -d '{"container_id":"MSCU1234567","event_type":"hub_received","notes":"Hub received container"}' \
  | python3 -m json.tool
echo ""
read -p "Border Post still OFFLINE. Press ENTER to bring it back online..."

# Step 6: Restore the Border Post
echo "[Step 6] Restoring Border Post (Site 2)..."
kubectl scale deployment postgres-border -n $NS --replicas=1
kubectl wait --for=condition=ready pod -l app=postgres-border -n $NS --timeout=60s
kubectl scale deployment site-border -n $NS --replicas=1
kubectl wait --for=condition=ready pod -l app=site-border -n $NS --timeout=60s
echo "  => Border Post is back ONLINE"
sleep 5   # allow sync worker to reconnect and replay events

# Step 7: Show all sites healthy again
echo "[Step 7] All sites should be ONLINE again..."
curl -s $GW/sites/health | python3 -m json.tool
echo ""

# Step 8: Check timeline — events from while Border was down should have synced
echo "[Step 8] Container MSCU1234567 full timeline (scatter-gathered across all sites)..."
echo "         Events recorded while Border was offline should now appear everywhere."
curl -s $GW/control-tower/milestones/MSCU1234567 | python3 -m json.tool
echo ""

echo "============================================================"
echo "  Demo Complete."
echo "  Key observations:"
echo "  • The Border Post came back with no data loss."
echo "  • Events from other sites synced automatically via NATS."
echo "  • ON CONFLICT DO NOTHING ensured no duplicates on replay."
echo "  • The control tower shows the complete timeline."
echo "============================================================"
